require 'mechanize'
require 'json'

class TikiScraper
  def initialize(base_url, options = {})
    @agent = Mechanize.new
    @agent.user_agent_alias = options[:browser] || 'Mac Safari' 
    @page = @agent.get(base_url)
    @agent.page.encoding = 'utf-8'
  end
  
  def start_and_save_as(filename)
    products = []
    loop do
      @page.search('.product-box-list .product-item a').each do |product|
        begin
          product_page = @agent.get(product['href'])
          
          name = name.text.strip if name = product_page.at('#product-name')
          brand = brand.text.strip if brand = product_page.at('.item-brand a')
          price = price.text.strip if price = product_page.at('#span-price')
          description = description.text.strip if description = product_page.at('#gioi-thieu')

          images = product_page.search('#gal1 .swiper-slide img').map do |img|
            img['src'].sub(/w300|42x42/, 'w1200')
          end
          if images.empty?
            images << product_page.at('#product-magiczoom')['src']
                      .sub(/w300|42x42/, 'w1200')
          end

          products << {
            name: name,
            brand: brand,
            price: price,
            description: description,
            images: images
          }
        rescue Exception => e
          next
        end
      end

      if next_page = @page.link_with(css: '.next')
        puts next_page.href
        @page = next_page.click

        # Handle when page redirecting
        if @page.code[/30[12]/]
          current_uri = @page.uri
          current_page_number = current_uri[/\d+$/].to_i
          @page.get(current_uri.gsub("#{current_page_number}", "#{current_page_number + 1}"))
        end
      else
        break
      end
    end

    File.open("#{filename}.json","w") do |f|
      f.write(products.to_json)
    end
  end
end

@category_agent = Mechanize.new
@category_agent.user_agent_alias = 'Mac Safari' 
@category_page = @category_agent.get('https://tiki.vn/the-thao')
@category_agent.page.encoding = 'utf-8'
@category_page.links_with(css: '.has-child').each do |sub_category|
  sub_category_url = "https://tiki.vn#{sub_category.href}"
  filename_to_save = sub_category.href[/\/.*?\//].gsub('-', '_').delete('/')

  scraper = TikiScraper.new(sub_category_url)
  scraper.start_and_save_as("the_thao/#{filename_to_save}")
end

puts "Done!!"


